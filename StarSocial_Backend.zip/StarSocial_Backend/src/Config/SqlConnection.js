const sql = require('mssql');
require('dotenv').config();
const dbConfig = {
    user: process.env.DB_User,
    password: process.env.DB_Password,
    server: process.env.DB_Server,
	port:1434,
    database: process.env.DB_Name,
    options: {
        encrypt: true, // bắt buộc nếu dùng Azure
        trustServerCertificate: true, // cần thiết cho local SQL Server
    },
    pool: {
        max: 10,
        min: 0,
        idleTimeoutMillis: 30000
    }

};

let pool;
const connection = async () => {
try{
    pool = await sql.connect(dbConfig);
    console.log("Kết nối đến cơ sở dữ liệu thành công!");
}
catch(err){
    console.error("Lỗi kết nối đến cơ sở dữ liệu:"+process.env.DB_User, err);
    throw err;
}};
connection();
module.exports = {connection};